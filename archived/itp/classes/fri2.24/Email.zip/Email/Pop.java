/* Daniel Shiffman               */
/* Spring 2006                   */
/* http://www.shiffman.net       */
/* daniel.shiffman@nyu.edu       */

/* Simple E-mail Checking        */

import java.util.Properties;
import javax.mail.*;

public class Pop {
  public static void main (String args[]) throws Exception {
    Properties props = System.getProperties();
    props.put("mail.pop3.host", "mail.shiffman.net");
    Auth auth = new Auth();
    Session session = Session.getDefaultInstance(props, auth);
    Store store = session.getStore("pop3");
    store.connect();
    Folder folder = store.getFolder("INBOX");
    folder.open(Folder.READ_ONLY);
    System.out.println(folder.getMessageCount() + " total messages.");
    Message message[] = folder.getMessages();
    for (int i=0; i < message.length; i++) {
       System.out.println("---------------------");
       System.out.println("Message # " + (i+1));
       System.out.println("From: " + message[i].getFrom()[0]);
       System.out.println("Subject: " + message[i].getSubject());
       System.out.println("Message:");
       String content = message[i].getContent().toString(); 
       System.out.println(content);
    }
    folder.close(false);
    store.close();
  }
}

