/* Daniel Shiffman               */
/* Spring 2006                   */
/* http://www.shiffman.net       */
/* daniel.shiffman@nyu.edu       */

/* Simple Authenticator          */

import javax.mail.*;

public class Auth extends Authenticator {
    
    public Auth() {
        super();
    }
    
    public PasswordAuthentication getPasswordAuthentication() {
        String username, password;
        username = "username";
        password = "password";
        System.out.println("authenticating. . ");
        return new PasswordAuthentication(username, password);
    }
}