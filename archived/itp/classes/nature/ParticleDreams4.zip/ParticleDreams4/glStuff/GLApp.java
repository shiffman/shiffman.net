/**
 * Collection of functions to init and run an OpenGL app using LWJGL.
 * <P>
 * Includes functions to handle:  <BR>
 *        Buffer allocation -- manage IntBuffer, ByteBuffer calls. <BR>
 *        Setup display mode, keyboard, mouse, native cursor <BR>
 *        Run main loop of application <BR>
 *        OpenGL functions -- convert screen/world coords, set modes, lights, etc. <BR>
 *        Utility functions -- load images, convert pixels, getTimeInMillis, etc. <BR>
 * 
 * Has a main() function to run as an application, though this class has only
 * minimal placeholder functionality.  It is meant to be subclassed,
 * and the subclass will define more elaborate render() mouseMove() functions, etc.
 * 
 * GLApp initializes the LWJGL environment for OpenGL rendering,
 * ie. creates a window, sets the display mode, inits mouse and keyboard,
 * then runs a loop.
 * 
 * Uses GLImage to load and hold image pixels.
 * 
 * Uses the IDX3D library to load and hold 3DS meshes.  See http://www.idx3d.ch
 * for the complete pure-java 3D library by Peter Walser.
 *
 * napier@potatoland.org
 */

package glStuff;

import java.util.*;
import java.nio.*;
import java.io.*;
import org.lwjgl.*;
import org.lwjgl.opengl.*;
import org.lwjgl.input.*;
import org.lwjgl.opengl.glu.*;



public class GLApp {
    // Just for reference
    public static final String GLAPP_VERSION = "1.3";
    //
    // Used when allocating native buffers for data types
    public static final int SIZE_DOUBLE = 8;
    public static final int SIZE_FLOAT = 4;
    public static final int SIZE_INT = 4;
    public static final int SIZE_BYTE = 1;
    //
    // Application settings
    public static boolean finished;      // App will exit when finished is true (ESC key sets finished=true)
    public static int cursorX, cursorY;
    public static boolean mouseButtonOneDown = false;
    public static long prevTime = 0;
    public static int frameCount = 0;
    public static long ticksPerSecond = 0;    // used to calc time in millis
    public static String windowTitle = "LWJGL Application";
    //
    // Default display settings (display settings in default.cfg will override these)
    // initDisplay() uses these to pick a Display and setup viewport shape.
    public static DisplayMode DM, origDM;       // hold display mode we set, and the display mode when app first executes
    public static int displayWidth = 1024;
    public static int displayHeight = 768;
    public static int displayColorBits = 32;
    public static int displayFrequency = 75;
    public static boolean fullScreen = true;    // full screen or floating window
    public static float aspectRatio = 0;        // aspect ratio of Display (will default to displayWidth/displayHeight)
    public static int viewportX, viewportY;     // viewport position (will default to 0,0)
    public static int viewportW, viewportH;     // viewport size (will default to screen width, height)
    //
    public static float tileFactor = 1f;      // how many times to repeat texture
    //
    static float rotation = 0f;         // to rotate cubes (just to put something on screen)

    //========================================================================
    // Run main loop of application.  Handle mouse and keyboard input.
    //
    // These functions (main(), run(), mainLoop() and loadSettings()) start
    // and run the application.  They call the init(), render(), and mouse
    // functions.
    //
    //========================================================================

    public static void main(String args[]) {
        GLApp demo = new GLApp();
        demo.run();
    }

    /**
     * Runs the application.  Calls init() functions to setup OpenGL,
     * input and display.  Runs the main loop of the application, which handles
     * mouse and keyboard input.
     * <P>
     * Calls:  init() and mainLoop(). <BR>
     * mainLoop() calls:  render(), mouseMove(), mouseDown(), mouseUp(), keyDown(), keyUp()
     */
    public void run() {
        double delay = 0d;
        int fcount = 0;
        // load settings from config file (display size, resolution, etc.)
        loadSettings("GLApp.cfg");
        try {
            // Init Display, Keyboard, Mouse, OpenGL
            init();
            // Main loop
            while (!finished) {
                if (!Display.isVisible()) {  //!!!
                    Thread.sleep(200L);
                }
                else if (Display.isCloseRequested()) {  //!!!
                    finished = true;
                }
                mainLoop();
                Display.update();  //!!!!
            }
        }
        catch (Exception e) {
            System.out.println("GLApp.run(): " + e);
            e.printStackTrace(System.out);
        }
        // prepare to exit
        cleanup();
        System.exit(0);
    }


    /**
     * Called by the run() loop.  Handles animation and input for each frame.
     */
    public void mainLoop() {
        // Handle mouse motion, clicks
        Mouse.poll();
        //if (Mouse.getEventX() != 0 || Mouse.getEventY() != 0 || Mouse.getDWheel() != 0) {
        //if (Mouse.getDX() != 0 || Mouse.getDY() != 0 || Mouse.getDWheel() != 0) {
            int cursX = Mouse.getX();
            int cursY = Mouse.getY();
            if (cursX >= 0 && cursX <= Display.getDisplayMode().getWidth()) {
                cursorX = cursX;
            }
            if (cursY >= 0 && cursY <= Display.getDisplayMode().getHeight()) {
                cursorY = cursY;
            }
            mouseMove(cursorX,cursorY);
        //}
        if (Mouse.isButtonDown(0)) {
            if (!mouseButtonOneDown) {
                mouseDown(cursorX, cursorY);
                mouseButtonOneDown = true;
            }
        }
        else {
            if (mouseButtonOneDown) {
                mouseUp(cursorX, cursorY);
                mouseButtonOneDown = false;
            }
        }
        // Handle key hits
        Keyboard.poll();
        for (int j = 0; j < Keyboard.getNumKeyboardEvents(); j++) {
            Keyboard.next();
            if (Keyboard.getEventKey() == Keyboard.KEY_ESCAPE && Keyboard.getEventKeyState()) {  // esc key hit
                finished = true;
            }
            
            if (Keyboard.getEventKeyState()) keyDown(Keyboard.getEventKey());
            else keyUp(Keyboard.getEventKey());
        }
        // Redraw the screen
        frameCount++;
        if ((Sys.getTime()-prevTime) > ticksPerSecond*1) {
            //System.out.println("==============> FramesPerSec=" + (frameCount/1) + " timeinsecs=" + getTimeInSeconds() + " timeinmillis=" + getTimeInMillis());
            prevTime = Sys.getTime();
            frameCount = 0;
        }
        render();
    }

    /**
     * Load configuration settings from properties file. File format is:<BR>
     *
     * <PRE>
     * # Comment
     * displayWidth=1024
     * displayHeight=768
     * </PRE>
     *
     * @param configFilename
     */
    public void loadSettings(String configFilename)
    {
        Properties settings = new Properties();
        try { settings.load(getInputStream(configFilename)); }
        catch (Exception e) {
            System.out.println("GLApp.loadSettings() error: " + e);
            return;
        }
        // Check for available settings
        if (settings.getProperty("displayWidth") != null) {
            displayWidth = Integer.parseInt(settings.getProperty("displayWidth"));
        }
        if (settings.getProperty("displayHeight") != null) {
            displayHeight = Integer.parseInt(settings.getProperty("displayHeight"));
        }
        if (settings.getProperty("displayColorBits") != null) {
            displayColorBits = Integer.parseInt(settings.getProperty("displayColorBits"));
        }
        if (settings.getProperty("displayFrequency") != null) {
            displayFrequency = Integer.parseInt(settings.getProperty("displayFrequency"));
        }
        if (settings.getProperty("aspectRatio") != null) {
            aspectRatio = Float.parseFloat(settings.getProperty("aspectRatio"));
        }
        if (settings.getProperty("fullScreen") != null) {
            fullScreen = settings.getProperty("fullScreen").toUpperCase().equals("YES");
        }
    }

    /**
     * Open a file InputStream and trap errors.
     * @param filenameOrURL
     * @return
     */
    public static InputStream getInputStream(String filename) {
        InputStream in = null;
        try {
            in = new FileInputStream(filename);
        }
        catch (IOException ioe) {
            System.out.println("GLApp.getInputStream (" + filename + "): " + ioe);
            if (in != null) {
                try {
                    in.close();
                    in = null;
                }
                catch (Exception e) {}
            }
        }
        catch (Exception e) {
            System.out.println("GLApp.getInputStream (" + filename + "): " + e);
        }
        return in;
    }


    //========================================================================
    // Custom Application functionality: can be overriden by subclass.
    //
    // Functions to initialize OpenGL, set the viewing mode, render the scene,
    // respond to mouse actions, and initialize the app.  These functions
    // are overridden in the subclass to create custom behavior.
    //
    //========================================================================

    /**
     * The three init functions below must be called to get the display, mouse
     * and OpenGL context ready for use. Override init() in a subclass to
     * customize behavior.
     */
    public void init()
    {
        // initialize Window, Keyboard, Mouse, OpenGL environment
        initDisplay();
        initInput();
        initOpenGL();
    }

    /**
     * Called by GLApp.run() to initialize OpenGL rendering.
     * @throws java.lang.Exception
     */
    public static void initOpenGL() {
        try {
            // Depth tests mess up alpha drawing.  When layering up many transluscent
            // shapes, you have to turn off Depth tests or GL will throw out "hidden"
            // layers, when you actually want to draw the lower layers under the
            // topmost (transluscent) layers.
            GL11.glClearDepth(1.0f); // Depth Buffer Setup
            GL11.glEnable(GL11.GL_DEPTH_TEST); // Enables Depth Testing  // Need this ON if using textures
            GL11.glDepthFunc(GL11.GL_LEQUAL); // The Type Of Depth Testing To Do

            // Needed?
            GL11.glShadeModel(GL11.GL_SMOOTH); // Enable Smooth Shading
            GL11.glClearColor(0f, 0f, 0f, 0f); // Black Background
            GL11.glEnable(GL11.GL_NORMALIZE);
            GL11.glEnable(GL11.GL_CULL_FACE);

            // Perspective quality
            GL11.glHint(GL11.GL_PERSPECTIVE_CORRECTION_HINT, GL11.GL_NICEST);

            // Set the size and shape of the screen area
            //GL11.glViewport(0, 0, Display.getWidth(), Display.getHeight());
            GL11.glViewport(viewportX, viewportY, viewportW, viewportH);

            // setup perspective (see setOrtho for 2D)
            setPerspective();
            //setOrtho();

            // select model view for subsequent transforms
            GL11.glMatrixMode(GL11.GL_MODELVIEW);
            GL11.glLoadIdentity();
        }
        catch (Exception e) {
            System.out.println("GLApp.initOpenGL(): " + e);
        }
    }


    /**
     * Called by mainLoop() to render one frame.  Subclass will override this.
     */
    public void render() {
        // select model view for subsequent transforms
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
        GL11.glLoadIdentity();

        // clear depth buffer and color
        GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);

        // rotate, scale and draw cube
        rotation += .3;
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GL11.glRotatef(rotation, (float)0, (float)1, (float)0);
        GL11.glColor4f(0f, .5f, 1f, 1f);
        renderCube();   // draw a cube
        GL11.glPopMatrix();

        // draw another overlapping cube
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GL11.glRotatef(rotation, (float)1, (float)1, (float)1);
        GL11.glColor4f(.7f, .5f, 0f, 1f);
        renderCube();
        GL11.glPopMatrix();
    }

    /**
     * Called by mainLoop() when mouse moves
     */
    public void mouseMove(int x, int y) {
    }


    public void mouseDown(int x, int y) {
    }


    public void mouseUp(int x, int y) {
    }


    public void keyDown(int keycode) {
    }


    public void keyUp(int keycode) {
    }


    /**
     * Run() calls this right before exit.
     */
    public static void cleanup() {
        destroyFont();
        Keyboard.destroy();
        Mouse.destroy();
        Display.destroy();
        //try {
        //    Display.resetDisplayMode();
        //}
        //catch (Exception exception) {
        //    exception.printStackTrace();
        //}
    }


    public GLApp() {
    }

    //========================================================================
    // Setup display mode
    //
    // Initialize Display, Mouse, Keyboard.
    // These functions are specific to LWJGL.
    //
    //========================================================================

    /**
     * Initialize the Display mode, viewport size, and open a Window.
     * By default the window is fullscreen, the viewport is the same dimensions
     * as the window.
     */
    public static boolean initDisplay () {
        origDM = Display.getDisplayMode();
        System.out.println("GLApp.initDisplay(): Current display mode is " + origDM);
        // Set display mode
        try {
            if ( (DM = getDisplayMode(displayWidth, displayHeight, displayColorBits, displayFrequency)) == null) {
                if ( (DM = getDisplayMode(1024, 768, 32, 60)) == null) {
                    if ( (DM = getDisplayMode(1024, 768, 16, 60)) == null) {
                        if ( (DM = getDisplayMode(800, 600, 16, 60)) == null) {
                            System.out.println("GLApp.initDisplay(): Can't find a compatible Display Mode!!!");
                        }
                    }
                }
            }
            System.out.println("GLApp.initDisplay(): Setting display mode to " + DM);
            Display.setDisplayMode(DM);
        }
        catch (Exception exception) {
            System.err.println("GLApp.initDisplay(): Failed to create display: " + exception);
        }
        // Initialize the Window
        try {
            Display.create(new PixelFormat(0, 24, 0));  // set bits per buffer: alpha, depth, stencil
            Display.setTitle(windowTitle);
            Display.setFullscreen(fullScreen);
            Display.setVSyncEnabled(true);
            System.out.println("GLApp.initDisplay(): Created OpenGL window.");
        }
        catch (Exception exception1) {
            System.err.println("GLApp.initDisplay(): Failed to create OpenGL window: " + exception1);
            System.exit(1);
        }
        // Set viewport width/height and Aspect ratio.
        if (aspectRatio == 0f) {
            // no aspect ratio was set in GLApp.cfg: default to full screen.
            aspectRatio = (float)Display.getDisplayMode().getWidth() / (float)Display.getDisplayMode().getHeight(); // calc aspect ratio of display
        }
        // viewport may not match shape of screen.  Adjust to fit.
        viewportH = DM.getHeight();                        // viewport Height
        viewportW = (int) (DM.getHeight() * aspectRatio);  // Width
        if (viewportW > DM.getWidth()) {
            viewportW = DM.getWidth();
            viewportH = (int) (DM.getWidth() * (1 / aspectRatio));
        }
        // center viewport in screen
        viewportX = (int) ((DM.getWidth()-viewportW) / 2);
        viewportY = (int) ((DM.getHeight()-viewportH) / 2);
        return true;
    }

    /**
     * Initialize the Keyboard and Mouse
     */
    public static void initInput() {
        try {
            // init keyboard
            Keyboard.create();
            //Keyboard.enableBuffer();

            // init mouse
            Mouse.create();

            // set initial cursor pos to center screen
            cursorX = (int) DM.getWidth() / 2;
            cursorY = (int) DM.getHeight() / 2;

            // Init hi-res timer
            //Sys.setTime(0L);   // defunct
            ticksPerSecond = Sys.getTimerResolution();

            // Give this process priority
            //Sys.setProcessPriority(Sys.NORMAL_PRIORITY); //HIGH_PRIORITY);
        }
        catch (Exception e) {
            System.out.println("GLApp.initInput(): " + e);
        }
    }


    /**
     * Retrieve a DisplayMode object with the given params
     */
    public static DisplayMode getDisplayMode(int w, int h, int colorBits,
                                              int freq) {
        DisplayMode adisplaymode[] = Display.getAvailableDisplayModes();
        DisplayMode dm = null;
        for (int j = 0; j < adisplaymode.length; j++) {
            dm = adisplaymode[j];
            if (dm.getWidth() == w && dm.getHeight() == h && dm.getBitsPerPixel() == colorBits &&
                dm.getFrequency() == freq) {
                return dm;
            }
        }
        return null;
    }


    //========================================================================
    // OpenGL functions
    //
    // Typical OpenGL functionality: get settings, get matrices, convert
    // screen to world coords, define textures and lights.
    //
    //========================================================================

    public static int getSettingInt(int whichSetting)
    {
        IntBuffer ibuffer = allocInts(1);
        GL11.glGetInteger(whichSetting, ibuffer);
        return ibuffer.get(0);
    }

    /**
     * Find the Z depth of the origin in the projected world view. Used by unproject()
     * Projectsion matrix  must be active for this to return correct results (GL.glMatrixMode(GL.GL_PROJECTION)).
     * For some reason I have to chop this to four decimals or I get bizarre
     * results when I use the value in project().
     */
    public static float getZDepthAtOrigin()
    {
        float[] resultf = new float[3];
        project( 0, 0, 0, resultf);
        return ((int)(resultf[2] * 10000F)) / 10000f;  // truncate to 4 decimals
    }

    public static FloatBuffer getModelviewMatrix()
    {
        FloatBuffer modelview = allocFloats(16);
        GL11.glGetFloat(GL11.GL_MODELVIEW_MATRIX, modelview);
        return modelview;
    }

    public static FloatBuffer getProjectionMatrix()
    {
        FloatBuffer projection = allocFloats(16);
        GL11.glGetFloat(GL11.GL_PROJECTION_MATRIX, projection);
        return projection;
    }

    public static IntBuffer getViewport()
    {
        IntBuffer viewport = allocInts(16);
        GL11.glGetInteger(GL11.GL_VIEWPORT, viewport);
        return viewport;
    }


    /**
     * Convert a FloatBuffer matrix to a 4x4 float array.
     * @param fb   FloatBuffer containing 16 values of 4x4 matrix
     * @return     2 dimensional float array
     */
    public static float[][] getMatrixAsArray(FloatBuffer fb) {
        float[][] fa = new float[4][4];
        fa[0][0] = fb.get();
        fa[0][1] = fb.get();
        fa[0][2] = fb.get();
        fa[0][3] = fb.get();
        fa[1][0] = fb.get();
        fa[1][1] = fb.get();
        fa[1][2] = fb.get();
        fa[1][3] = fb.get();
        fa[2][0] = fb.get();
        fa[2][1] = fb.get();
        fa[2][2] = fb.get();
        fa[2][3] = fb.get();
        fa[3][0] = fb.get();
        fa[3][1] = fb.get();
        fa[3][2] = fb.get();
        fa[3][3] = fb.get();
        return fa;
    }

    /**
     * Return the modelview matrix as a 4x4 float array
     */
    public static float[][] getModelviewMatrixA()
    {
        FloatBuffer b = getModelviewMatrix();
        return getMatrixAsArray(b);
    }

    /**
     * Return the projection matrix as a 4x4 float array
     */
    public static float[][] getProjectionMatrixA()
    {
        FloatBuffer b = getProjectionMatrix();
        return getMatrixAsArray(b);
    }

    /**
     * Return the Viewport data as array of 4 floats
     */
    public static int[] getViewportA()
    {
        IntBuffer ib = getViewport();
        int[] ia = new int[4];
        ia[0] = ib.get(0);
        ia[1] = ib.get(1);
        ia[2] = ib.get(2);
        ia[3] = ib.get(3);
        return ia;
    }


    /**
     * Return the Z depth of the single pixel at the given screen position.
     */
    public static float getZDepth(int x, int y)
    {
        ByteBuffer zdepth = ByteBuffer.allocateDirect(1 * SIZE_FLOAT).order(ByteOrder.nativeOrder());
        GL11.glReadPixels(x, y, 1, 1, GL11.GL_DEPTH_COMPONENT, GL11.GL_FLOAT, zdepth);
        return ( (float) (zdepth.getFloat(0)));
    }


    /**
     * Return screen coordinates for a given point in world space.  The world
     * point xyz is 'projected' into screen coordinates using the current model
     * and projection matrices, and the current viewport settings.
     *
     * @param x         world coordinates
     * @param y
     * @param z
     * @param resultf    the screen coordinate as an array of 3 floats
     */
    public static void project(float x, float y, float z, float[] resultf)
    {
        float[] result = new float[3];
        GLU.gluProject( x, y, z, getModelviewMatrixA(), getProjectionMatrixA(), getViewportA(), result);
        resultf[0] = result[0];
        resultf[1] = result[1];
        resultf[2] = result[2];
    }


    /**
     * Return world coordinates for a given point on the screen.  The screen
     * point xyz is 'un-projected' back into world coordinates using the
     * current model and projection matrices, and the current viewport settings.
     *
     * @param x         screen x position
     * @param y         screen y position
     * @param z         z-buffer depth position
     * @param resultf   the world coordinate as an array of 3 floats
     * @see             getWorldCoordsAtScreen()
     */
    public static void unProject(float x, float y, float z, float[] resultf)
    {
        float[] result = new float[3];  // v.9
        GLU.gluUnProject( x, y, z, getModelviewMatrixA(), getProjectionMatrixA(), getViewportA(), result);
        resultf[0] = result[0];
        resultf[1] = result[1];
        resultf[2] = result[2];
    }

    /**
     * For given screen xy, return the world xyz coords in a float array.  Assume
     * Z position is 0.
     */
    protected static float[] getWorldCoordsAtScreen(int x, int y) {
        float z = getZDepthAtOrigin();
        float[] resultf = new float[3];
        unProject( (float)x, (float)y, (float)z, resultf);
        return resultf;
    }

    /**
     * Allocate a texture (glGenTextures) and return the handle to it.
     */
    public static int allocateTexture()
    {
        IntBuffer textureHandle = allocInts(1);
        GL11.glGenTextures(textureHandle);
        return textureHandle.get(0);
    }

    /**
     * Create a texture from the given image.
     */
    public static int makeTexture(GLImage textureImg)
    {
        return makeTexture(textureImg.pixelBuffer, textureImg.w, textureImg.h);
    }

    /**
     * Create a texture from the given pixels in RGBA format.  Set the texture
     * to repeat in both directions and use LINEAR for magnification.
     * @return  the texture handle
     */
    public static int makeTexture(ByteBuffer pixels, int w, int h)
    {
        // get a new empty texture
        int textureHandle = allocateTexture();
        // 'select' the new texture by it's handle
        GL11.glBindTexture(GL11.GL_TEXTURE_2D,textureHandle);
        // set texture parameters
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL11.GL_REPEAT);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL11.GL_REPEAT);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR); //GL11.GL_NEAREST);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR); //GL11.GL_NEAREST);
        // Create the texture from pixels
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA, w, h, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, pixels);
        return textureHandle;
    }

    /**
     * Build Mipmaps for texture (builds different versions of the picture for
     * distances - looks better)
     *
     * @param textureImg  the texture image
     * @return   error code of buildMipMap call
     */
    public static int makeTextureMipMap(GLImage textureImg)
    {
        int ret = GLU.gluBuild2DMipmaps(GL11.GL_TEXTURE_2D, 4, textureImg.w,
                          textureImg.h, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, textureImg.getPixelsRGBA());
        if (ret != 0) {
            System.out.println("GLApp.makeTextureMipMap(): Error occured while building mip map, ret=" + ret);
        }
        //Assign the mip map levels and texture info
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR_MIPMAP_NEAREST);
        GL11.glTexEnvf(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_MODULATE);
        return ret;
    }

    /**
     * Set OpenGL to render in 3D perspective.
     */
    public static void setPerspective()
    {
        // select projection matrix (controls view on screen)
        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glLoadIdentity();
        //GLU.gluPerspective(30f, aspectRatio, 1f, 30f);
        GLU.gluPerspective(30f, aspectRatio, 1f, 200.0f);
        //gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,0.1f,200.0f);
        GLU.gluLookAt(0f, 0f, 15f, 0f, 0f, 0f, 0f, 1f, 0f);
    }

    /**
     * Set OpenGL to render in flat 2D (no perspective).
     */
    public static void setOrtho()
    {
        // select projection matrix (controls view on screen)
        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glLoadIdentity();
        GLU.gluOrtho2D(0f, DM.getWidth(), 0f, DM.getHeight());
    }

    /**
     * Set OpenGL to render in flat 2D (no perspective) on top of current scene.
     * Preserve current projection and model views, and disable depth testing.
     * Once Ortho is On, glTranslate() will take pixel coords as arguments,
     * with the lower left corner 0,0 and the upper right corner 1024,768 (or
     * whatever your screen size is).
     *
     * @see setOrthoOff()
     */
    public static void setOrthoOn()
    {
        // prepare to render in 2D
        GL11.glDisable(GL11.GL_DEPTH_TEST);                   // so text stays on top of scene
        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glPushMatrix();                                  // preserve perspective view
        GL11.glLoadIdentity();                                // clear the perspective matrix
        //GL11.glOrtho(0,Display.getWidth(),0,Display.getHeight(),-1,1);  // turn on 2D mode
        GL11.glOrtho(viewportX,viewportX+viewportW,viewportY,viewportY+viewportH,-1,1);  // turn on 2D mode
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
        GL11.glPushMatrix();				// Preserve the Modelview Matrix
        GL11.glLoadIdentity();				// clear the Modelview Matrix
    }

    /**
     * Turn 2D mode off.  Return the projection and model views to their
     * preserved state that was saved when setOrthoOn() was called, and
     * enable depth testing.
     *
     * @see setOrthoOn()
     */
    public static void setOrthoOff()
    {
        // restore the original positions and views
        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glPopMatrix();
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
        GL11.glPopMatrix();
        GL11.glEnable(GL11.GL_DEPTH_TEST);		// turn Depth Testing back on
    }

    /**
     * Set the color of a 'positional' light (a light that has a specific
     * position within the scene).  <BR>
     *
     * Pass in an OpenGL light number (GL11.GL_LIGHT1),
     * the 'Diffuse' and 'Ambient' colors (direct light and reflected light),
     * and the position.<BR>
     *
     * @param GLLightHandle
     * @param diffuseLightColor
     * @param ambientLightColor
     * @param position
     */
    public static void setLight( int GLLightHandle,
        float[] diffuseLightColor, float[] ambientLightColor, float[] position )
    {
        FloatBuffer ltDiffuse = allocFloats(diffuseLightColor);
        FloatBuffer ltAmbient = allocFloats(ambientLightColor);
        FloatBuffer ltPosition = allocFloats(position);
        GL11.glLight(GLLightHandle, GL11.GL_DIFFUSE, ltDiffuse);   // color of the direct illumination
        GL11.glLight(GLLightHandle, GL11.GL_SPECULAR, ltDiffuse);  // color of the highlight
        GL11.glLight(GLLightHandle, GL11.GL_AMBIENT, ltAmbient);   // color of the reflected light
        GL11.glLight(GLLightHandle, GL11.GL_POSITION, ltPosition);
        GL11.glEnable(GLLightHandle);	// Enable the light (GL_LIGHT1 - 7)
        //GL11.glLightf(GLLightHandle, GL11.GL_QUADRATIC_ATTENUATION, .005F);    // how light beam drops off
    }


    public static void setSpotLight( int GLLightHandle,
        float[] diffuseLightColor, float[] ambientLightColor,
        float[] position, float[] direction, float cutoffAngle )
    {
        FloatBuffer ltDirection = allocFloats(direction);
        setLight(GLLightHandle, diffuseLightColor, ambientLightColor, position);
        GL11.glLightf(GLLightHandle, GL11.GL_SPOT_CUTOFF, cutoffAngle);   // width of the beam
        GL11.glLight(GLLightHandle, GL11.GL_SPOT_DIRECTION, ltDirection);    // which way it points
        GL11.glLightf(GLLightHandle, GL11.GL_CONSTANT_ATTENUATION, 2F);    // how light beam drops off
        //GL11.glLightf(GLLightHandle, GL11.GL_LINEAR_ATTENUATION, .5F);    // how light beam drops off
        //GL11.glLightf(GLLightHandle, GL11.GL_QUADRATIC_ATTENUATION, .5F);    // how light beam drops off
    }

    /**
     * Set the color of the Global Ambient Light.  Affects all objects in
     * scene regardless of their placement.
     */
    public static void setAmbientLight(float[] ambientLightColor)
    {
        FloatBuffer ltAmbient = allocFloats(ambientLightColor);
        GL11.glLightModel(GL11.GL_LIGHT_MODEL_AMBIENT, ltAmbient);
    }


    //========================================================================
    // Utility functions
    //
    // Functions to load images, convert byte order, make cursors,
    // grab framebuffer pixels, draw pixels into framebuffer.
    //
    //========================================================================

    public static double getTimeInSeconds()
    {
        if (ticksPerSecond == 0) {
            ticksPerSecond = Sys.getTimerResolution();
        }
        return (((double)Sys.getTime())/(double)ticksPerSecond);
    }

    public static double getTimeInMillis()
    {
        if (ticksPerSecond == 0) {
            ticksPerSecond = Sys.getTimerResolution();
        }
        return (double) ((((double)Sys.getTime())/(double)ticksPerSecond) * 1000.0);
    }

    /**
     * Load an image from the given file and return a GLImage object.
     * @param imgFilename
     * @return
     */
    public static GLImage loadImage(String imgFilename) {
        GLImage img = new GLImage(imgFilename);
        if (img.isLoaded()) {
            return img;
        }
        return null;
    }

    /**
     * Load an image from the given file and return a ByteBuffer containing RGBA pixels.<BR>
     * Can be used to create textures. <BR>
     * @param imgFilename
     * @return
     */
    public static ByteBuffer loadImagePixels(String imgFilename) {
        GLImage img = new GLImage(imgFilename);
        return img.pixelBuffer;
    }

    /**
     * Load an image from the given file and return an IntBuffer containing ARGB pixels.<BR>
     * Can be used to create Native Cursors. <BR>
     * @param imgFilename
     * @return IntBuffer
     */
    public static IntBuffer loadImageInt(String imgFilename) {
        GLImage img = new GLImage(imgFilename);
        int[] jpixels = img.getImagePixels();      // pixels in Java int format
        return allocInts(jpixels);  // convert to IntBuffer and return
    }

    /**
     * Draw an image at the given x,y. If scale values are not 1, then scale
     * the image.  See loadImage().<BR>
     */
    public static void drawImageInt(GLImage img, int x, int y, float scaleW, float scaleY) {
        if (img != null) {
            GL11.glRasterPos2i(x, y);
            GL11.glDrawPixels(img.w, img.h, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, img.pixelBuffer);
            if (scaleW != 1f || scaleY != 1f) {
                GL11.glPixelZoom(scaleW, scaleY);
            }
        }
    }

    /**
     * Draw an image at the given x,y. Scale the image to the given w,h.
     * The image must be loaded into the texture pointed to by textureHandle.
     * It will be drawn in 2D on top of the current scene.
     * <BR>
     * @ee loadImage().
     */
    public static void drawImageQuad(int textureHandle, int x, int y, float w, float h) {
        // activate the specified texture
        GL11.glBindTexture(GL11.GL_TEXTURE_2D,textureHandle);
        // prepare to render in 2D
        setOrthoOn();
        // draw the image textured onto a quad
        GL11.glBegin(GL11.GL_QUADS);
        GL11.glTexCoord2f(0f, 0f);
        GL11.glVertex3f( (float)x, (float)y, (float)0);
        GL11.glTexCoord2f(1f, 0f);
        GL11.glVertex3f( (float)x+w, (float)y, (float)0);
        GL11.glTexCoord2f(1f, 1f);
        GL11.glVertex3f( (float)x+w, (float)y+h, (float)0);
        GL11.glTexCoord2f(0f, 1f);
        GL11.glVertex3f( (float)x, (float)y+h, (float)0);
        GL11.glEnd();
        // restore the previous perspective and model views
        setOrthoOff();
    }

    /**
     * Create a native cursor from the given image file.<BR>
     * @param imgFilename
     * @return Cursor
     */
    /*public static Cursor makeNativeCursor(String imgFilename) {
        // check for hw cursor
        if ( (Mouse.getNativeCursorCaps() & Mouse.CURSOR_ONE_BIT_TRANSPARENCY) == 0) {
            System.out.println("GLApp.makeNativeCursor(): No hardware cursor support!");
            return null;
        }
        // load the image
        GLImage img = new GLImage(imgFilename);
        int[] jpixels = img.getImagePixels();      // pixels in Java int format
        int w = img.w;
        int h = img.h;
        // check for legal image size
        if ( w < Mouse.getMinCursorSize() || w > Mouse.getMaxCursorSize()
             || h < Mouse.getMinCursorSize() || h > Mouse.getMaxCursorSize() ) {
            System.out.println("GLApp.makeNativeCursor(): Cursor image is not correct size, should be " + Mouse.getMinCursorSize() + "-" + Mouse.getMaxCursorSize());
            return null;
        }
        // correct transparent pixels: if a pixel has partial alpha (anything less
        // than opaque) set entire pixel to 0.  Otherwise transparent area looks funky.
        for (int i=0; i < jpixels.length; i++) {
            if ( (jpixels[i] >> 24 & 0xff) != 0xff) {
                jpixels[i] = 0;
            }
        }
        // make the cursor
        IntBuffer intpixels =  allocInts(jpixels);  // convert to IntBuffer
        Cursor C = null;
        try {
            C = new Cursor(w, h,        // cursor size
                           w/2, h/2,    // hotspot at center
                           1,           // one cursor image will be passed in
                           intpixels,   // image pixels
                           null);       // no delays (timing delays for animated cursors)
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return C;
    }*/


    /**
     * Get pixels from frame buffer.<BR>
     */
    public static GLImage getFramePixels(int x, int y, int w, int h) {
        ByteBuffer pixels = allocBytes(w*h);
        //GL11.glReadBuffer(GL11.GL_BACK);
        GL11.glReadPixels(x,y,w,h,GL11.GL_RGBA,GL11.GL_UNSIGNED_BYTE, pixels);
        return new GLImage(pixels,w,h);
    }

    /**
     * Get pixels from frame buffer into an existing image.<BR>
     */
    public static void getFramePixels(int x, int y, GLImage img) {
        GL11.glReadPixels(x,y, img.w, img.h, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, img.pixelBuffer);
    }

    /**
     * Write pixels to frame buffer from an existing image.
     * <BR>
     * Need to switch Projection matrix to ortho (2D) since Raster Position is
     * transformed in space just like a vertex.  Steps: switch to 2D, set the
     * draw position to lower left, draw the image into Back and Front buffers.
     * <BR>
     * Draw into both buffers so they both have same image (otherwise you may
     * get flicker as front and back buffers have different images).  This is
     * an issue only when you're not clearing the screen before drawing each
     * frame, ie. when leaving trails as objects move.
     */
    public static void setFramePixels(GLImage img) {
        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GLU.gluOrtho2D(0f, DM.getWidth(), 0f, DM.getHeight());
        GL11.glRasterPos2i(0,0);
        GL11.glDrawBuffer(GL11.GL_FRONT);
        GL11.glDrawPixels(img.w, img.h, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, img.pixelBuffer);
        GL11.glDrawBuffer(GL11.GL_BACK);
        GL11.glDrawPixels(img.w, img.h, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, img.pixelBuffer);
        GL11.glPopMatrix();
    }


    /**
     * Copy current framebuffer to a texture.
     */
    public static void frameSave() {
        // Select texture 2, then call copyTexImage (should this use viewport or Display dimensions?)
        //GL11.glReadBuffer(GL11.GL_FRONT);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D,2);
        GL11.glCopyTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA, 0,0,DM.getWidth(),DM.getWidth(), 0);
    }


    /**
     * Draw a front facing quad to cover the entire screen.  Quad is textured
     * with an image that will completely overwrite screen.
     */
    public static void frameRestore() {
        int H = DM.getWidth();
        int W = DM.getWidth();
        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GLU.gluOrtho2D(0f, (float)DM.getWidth(), 0f, (float)DM.getHeight());

        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_REPLACE);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D,2);  // TEST ONLY (should not be hard-coded!!!)
        GL11.glBegin(GL11.GL_QUADS);
        GL11.glTexCoord2f( 1f,  0f);       GL11.glVertex3f(  W, 0f, 0f);
        GL11.glTexCoord2f( 1f,  1f);       GL11.glVertex3f(  W,  H, 0f);
        GL11.glTexCoord2f( 0f,  1f);       GL11.glVertex3f( 0f,  H, 0f);
        GL11.glTexCoord2f( 0f,  0f);       GL11.glVertex3f( 0f, 0f, 0f);
        GL11.glEnd();
        GL11.glDisable(GL11.GL_TEXTURE_2D);

        GL11.glPopMatrix();
    }

    /**
     * Make a blank image of the given size<BR>
     */
    public static GLImage makeImage(int w, int h) {
        ByteBuffer pixels = allocBytes(w*h*4);
        return new GLImage(pixels,w,h);
    }

    /**
     * Render a unit cube, using current color, texture and material.
     * @param o
     */
    public static void renderCube()
    {
        GL11.glBegin(GL11.GL_QUADS);
        // Front Face
        GL11.glTexCoord2f(0.0f, 0.0f); GL11.glVertex3f(-1.0f, -1.0f,  1.0f);	// Bottom Left Of The Texture and Quad
        GL11.glTexCoord2f(1.0f, 0.0f); GL11.glVertex3f( 1.0f, -1.0f,  1.0f);	// Bottom Right Of The Texture and Quad
        GL11.glTexCoord2f(1.0f, 1.0f); GL11.glVertex3f( 1.0f,  1.0f,  1.0f);	// Top Right Of The Texture and Quad
        GL11.glTexCoord2f(0.0f, 1.0f); GL11.glVertex3f(-1.0f,  1.0f,  1.0f);	// Top Left Of The Texture and Quad
        // Back Face
        GL11.glTexCoord2f(1.0f, 0.0f); GL11.glVertex3f(-1.0f, -1.0f, -1.0f);	// Bottom Right Of The Texture and Quad
        GL11.glTexCoord2f(1.0f, 1.0f); GL11.glVertex3f(-1.0f,  1.0f, -1.0f);	// Top Right Of The Texture and Quad
        GL11.glTexCoord2f(0.0f, 1.0f); GL11.glVertex3f( 1.0f,  1.0f, -1.0f);	// Top Left Of The Texture and Quad
        GL11.glTexCoord2f(0.0f, 0.0f); GL11.glVertex3f( 1.0f, -1.0f, -1.0f);	// Bottom Left Of The Texture and Quad
        // Top Face
        GL11.glTexCoord2f(0.0f, 1.0f); GL11.glVertex3f(-1.0f,  1.0f, -1.0f);	// Top Left Of The Texture and Quad
        GL11.glTexCoord2f(0.0f, 0.0f); GL11.glVertex3f(-1.0f,  1.0f,  1.0f);	// Bottom Left Of The Texture and Quad
        GL11.glTexCoord2f(1.0f, 0.0f); GL11.glVertex3f( 1.0f,  1.0f,  1.0f);	// Bottom Right Of The Texture and Quad
        GL11.glTexCoord2f(1.0f, 1.0f); GL11.glVertex3f( 1.0f,  1.0f, -1.0f);	// Top Right Of The Texture and Quad
        // Bottom Face
        GL11.glTexCoord2f(1.0f, 1.0f); GL11.glVertex3f(-1.0f, -1.0f, -1.0f);	// Top Right Of The Texture and Quad
        GL11.glTexCoord2f(0.0f, 1.0f); GL11.glVertex3f( 1.0f, -1.0f, -1.0f);	// Top Left Of The Texture and Quad
        GL11.glTexCoord2f(0.0f, 0.0f); GL11.glVertex3f( 1.0f, -1.0f,  1.0f);	// Bottom Left Of The Texture and Quad
        GL11.glTexCoord2f(1.0f, 0.0f); GL11.glVertex3f(-1.0f, -1.0f,  1.0f);	// Bottom Right Of The Texture and Quad
        // Right face
        GL11.glTexCoord2f(1.0f, 0.0f); GL11.glVertex3f( 1.0f, -1.0f, -1.0f);	// Bottom Right Of The Texture and Quad
        GL11.glTexCoord2f(1.0f, 1.0f); GL11.glVertex3f( 1.0f,  1.0f, -1.0f);	// Top Right Of The Texture and Quad
        GL11.glTexCoord2f(0.0f, 1.0f); GL11.glVertex3f( 1.0f,  1.0f,  1.0f);	// Top Left Of The Texture and Quad
        GL11.glTexCoord2f(0.0f, 0.0f); GL11.glVertex3f( 1.0f, -1.0f,  1.0f);	// Bottom Left Of The Texture and Quad
        // Left Face
        GL11.glTexCoord2f(0.0f, 0.0f); GL11.glVertex3f(-1.0f, -1.0f, -1.0f);	// Bottom Left Of The Texture and Quad
        GL11.glTexCoord2f(1.0f, 0.0f); GL11.glVertex3f(-1.0f, -1.0f,  1.0f);	// Bottom Right Of The Texture and Quad
        GL11.glTexCoord2f(1.0f, 1.0f); GL11.glVertex3f(-1.0f,  1.0f,  1.0f);	// Top Right Of The Texture and Quad
        GL11.glTexCoord2f(0.0f, 1.0f); GL11.glVertex3f(-1.0f,  1.0f, -1.0f);	// Top Left Of The Texture and Quad
        GL11.glEnd();
    }


    //========================================================================
    // Functions to build a character set and draw text strings.
    //
    // Example:
    //           buildFont("Font_tahoma.png");
    //           ...
    //           glPrint(100, 100, 0, "Here's some text");
    //           ...
    //           destroyFont();   // cleanup
    //========================================================================

    static int fontListBase = -1;           // Base Display List For The character set
    static int fontTextureHandle = -1;      // Texture handle for character set image

    /**
     * Build a character set from the given texture image.
     *
     * @param charSetImage   texture image containing 256 characters in a 16x16 grid
     * @param fontWidth      how many pixels to allow per character on screen
     *
     * @see       destroyFont()
     */
    public static void buildFont(String charSetImage, int fontWidth)
    {
        // make texture from image
        GLImage textureImg = loadImage(charSetImage);
        fontTextureHandle = makeTexture(textureImg);
        // build character set as call list of 256 textured quads
        buildFont(fontTextureHandle, 12);
    }

    /**
      * Build the character set display list from the given texture.  Creates
      * one quad for each character, with one letter textured onto each quad.
      * Assumes the texture is a 256x256 image containing every
      * character of the charset arranged in a 16x16 grid.  Each character
      * is 16x16 pixels.  Call destroyFont() to release the display list memory.
      *
      * Should be in ORTHO (2D) mode to render text (see setOrtho()).
      *
      * Special thanks to NeHe and Giuseppe D'Agata for the "2D Texture Font"
      * tutorial (http://nehe.gamedev.net).
      *
      * @param charSetImage   texture image containing 256 characters in a 16x16 grid
      * @param fontWidth      how many pixels to allow per character on screen
      *
      * @see       destroyFont()
      */
    public static void buildFont(int fontTxtrHandle, int fontWidth)
    {
        float cx, cy;
        fontListBase = GL11.glGenLists(256); // Creating 256 Display Lists
        for (int i = 0; i < 256; i++) {
            cx = (float) (i % 16) / 16f;              // X Texture Coord Of Character (0 - 1.0)
            cy = (float) (i / 16) / 16f;              // Y Texture Coord Of Character (0 - 1.0)
            GL11.glNewList(fontListBase + i, GL11.GL_COMPILE); // Start Building A List
            GL11.glBegin(GL11.GL_QUADS);              // Use A 16x16 pixel Quad For Each Character
            GL11.glTexCoord2f(cx, 1 - cy - 0.0625f);  // Texture Coord (Bottom Left)
            GL11.glVertex2i(0, 0);
            GL11.glTexCoord2f(cx + 0.0625f, 1 - cy - 0.0625f); // Texture Coord (Bottom Right)
            GL11.glVertex2i(16, 0);
            GL11.glTexCoord2f(cx + 0.0625f, 1 - cy);   // Texture Coord (Top Right)
            GL11.glVertex2i(16, 16);
            GL11.glTexCoord2f(cx, 1 - cy);             // Texture Coord (Top Left)
            GL11.glVertex2i(0, 16);
            GL11.glEnd();                              // Done Building Our Quad (Character)
            GL11.glTranslatef(fontWidth, 0, 0);        // Move To The Right Of The Character
            GL11.glEndList();                          // Done Building The Display List
        } // Loop Until All 256 Are Built
    }

    /**
     * Clean up the allocated display lists for the character set.
     */
    public static void destroyFont()
    {
        if (fontListBase != -1) {
            GL11.glDeleteLists(fontListBase,256);
            fontListBase = -1;
        }
    }

    /**
      * Render a text string onto the screen, using the character set created
      * by buildCharSet().
      */
     public static void glPrint(int x, int y, int set, String msg)
     {
         int offset = fontListBase - 32 + (128 * set);
         if (fontListBase == -1 || fontTextureHandle == -1) {
             System.out.println("GLApp.glPrint(): character set has not been created -- run buildCharSet() first");
             return;
         }
         if (msg != null) {
             // enable the charset texture
             GL11.glBindTexture(GL11.GL_TEXTURE_2D, fontTextureHandle);
             // prepare to render in 2D
             setOrthoOn();
             // draw the text
             GL11.glTranslatef(x, y, 0);        // Position The Text (in pixels coords)
             for(int i=0; i<msg.length(); i++) {
                 GL11.glCallList(offset + msg.charAt(i));
             }
             // restore the original positions and views
             setOrthoOff();
         }
     }


     //========================================================================
     // Buffer allocation functions
     //
     // These functions create and populate the native buffers used by LWJGL.
     //========================================================================

     public static ByteBuffer allocBytes(int howmany) {
         return ByteBuffer.allocateDirect(howmany * SIZE_BYTE).order(ByteOrder.nativeOrder());
     }

     public static IntBuffer allocInts(int howmany) {
         return ByteBuffer.allocateDirect(howmany * SIZE_INT).order(ByteOrder.nativeOrder()).asIntBuffer();
     }

     public static FloatBuffer allocFloats(int howmany) {
         return ByteBuffer.allocateDirect(howmany * SIZE_FLOAT).order(ByteOrder.nativeOrder()).asFloatBuffer();
     }

     public static DoubleBuffer allocDoubles(int howmany) {
         return ByteBuffer.allocateDirect(howmany * SIZE_DOUBLE).order(ByteOrder.nativeOrder()).asDoubleBuffer();
     }

     public static ByteBuffer allocBytes(byte[] bytearray) {
         ByteBuffer bb = ByteBuffer.allocateDirect(bytearray.length * SIZE_BYTE).order(ByteOrder.nativeOrder());
         bb.put(bytearray).flip();
         return bb;
     }

     public static IntBuffer allocInts(int[] intarray) {
         IntBuffer ib = ByteBuffer.allocateDirect(intarray.length * SIZE_FLOAT).order(ByteOrder.nativeOrder()).asIntBuffer();
         ib.put(intarray).flip();
         return ib;
     }

     public static FloatBuffer allocFloats(float[] floatarray) {
         FloatBuffer fb = ByteBuffer.allocateDirect(floatarray.length * SIZE_FLOAT).order(ByteOrder.nativeOrder()).asFloatBuffer();
         fb.put(floatarray).flip();
         return fb;
     }
     
     float constrain(float val,float min,float max) {
     	if (val < min) val = min;
     	if (val > max) val = max;
     	return val;
     }
     

}