/*
 * Created on Feb 17, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package glStuff;

/**
 * Create a simple 3D scene using functions in GLApp. Sets up a scene with an
 * object, textures and a light. Responds to mouse motion and click.
 * <P>
 * GLApp initializes the LWJGL environment for OpenGL rendering, ie. creates a
 * window, sets the display mode, inits mouse and keyboard, then runs a loop
 * that calls render().
 * <P>
 * Uses the IDX3D library to load and hold 3DS meshes. See http://www.idx3d.ch
 * for the complete pure-java 3D library by Peter Walser.
 * <P>
 * napier@potatoland.org
 */

//import java.util.*;
//import java.io.*;
//import java.nio.*;
//import org.lwjgl.*;
import java.util.ArrayList;

import org.lwjgl.opengl.*;
//import org.lwjgl.input.*;
import org.lwjgl.opengl.glu.*;

import vxp.*;
//import vxp.PixelSource;
//import vxp.QTLivePixelSource;
//import vxp.QTMoviePixelSource;
//import vxp.VideoListener;

import particles.*;

public class Reve extends GLApp {
	// Use IDX3D library to load meshes
	// Handles to two textures
	int particleTextureHandle = 0;

	// Lighting colors
	float faBlack[] = { 0f, 0f, 0f, 1.0f };

	float faLightBlue[] = { 0.8f, 0.8f, .9f, 1f };

	float faWhite[] = { 1.0f, 1.0f, 1.0f, 1.0f };

	float lightPosition[] = { -2f, -2f, 2f, 1.0f }; // if last value is 0, then

	// this describes light
	// direction. If 1, then
	// light position.

	float lightDirection[] = { 1f, 1f, -1f };

	// World coordintates at current mouse position
	float[] worldPos = { 0f, 0f, 0f };

	// World coordinates of sphere

	//ArrayList psystems;

	final static int W = 80;
	final static int H = 60;

	int mouseX, mouseY;

	ParticleSystem[] psystems = new ParticleSystem[W * H];
	
	ArrayList flyingSystems;

	PixelSource video;
	
	int[] before;
	
	float rot;
	
	int spotmax = 1;
	
	public static float coh_weight = 2.00f;
	public static float ali_weight = 1.00f;
	
	boolean up,down,left,right = false;
    boolean akey = false;
	/**
	 * Initialize the scene. Called by GLApp.run()
	 */
	public void init() {
		// initialize Window, Keyboard, Mouse, OpenGL environment
		initDisplay();
		initInput();
		initOpenGL();

		// setup perspective
		//setPerspective();

		// Create a light (diffuse light, ambient light, position)
		//setLight( GL11.GL_LIGHT1, faWhite, faLightBlue, lightPosition );

		// no overall scene lighting
		//setAmbientLight(faLightBlue);

		// enable lighting and texture rendering
		//GL11.glEnable(GL11.GL_LIGHTING);
		//GL11.glEnable(GL11.GL_TEXTURE_2D);

		// select model view for subsequent transforms
		//GL11.glMatrixMode(GL11.GL_MODELVIEW);
		//GL11.glLoadIdentity();

		GL11.glShadeModel(GL11.GL_SMOOTH); // Enable Smooth Shading
		GL11.glClearColor(0.0f, 0.0f, 0.0f, 0.0f); // Black Background
		GL11.glClearDepth(1.0f); // Depth Buffer Setup
		GL11.glDisable(GL11.GL_DEPTH_TEST); // Disable Depth Testing
		GL11.glEnable(GL11.GL_BLEND); // Enable Blending
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE); // Type Of Blending To
		GL11.glHint(GL11.GL_PERSPECTIVE_CORRECTION_HINT, GL11.GL_NICEST); // Really
		GL11.glHint(GL11.GL_POINT_SMOOTH_HINT, GL11.GL_NICEST);
		GL11.glEnable(GL11.GL_TEXTURE_2D); // Enable Texture Mapping

		// Create textures
		GLImage textureImg = loadImage("images/texture.gif");
		particleTextureHandle = makeTexture(textureImg);

		GL11.glBindTexture(GL11.GL_TEXTURE_2D, particleTextureHandle); // Select
		// Our
		// Texture
		
		flyingSystems = new ArrayList();
		
		int xstep = displayWidth / W;
		int ystep = displayHeight / H;

		int count = 0;
		for (int j = 0; j < displayHeight; j += ystep) {
			for (int i = 0; i < displayWidth; i += xstep) {
				float[] spot = new float[3];
				spot = getWorldCoordsAtScreen(i, j);
				psystems[count] = new ParticleSystem(spotmax, new Vector3D(spot[0],
						spot[1], 0));//-10));
				count++;
			}

		}

		//video = new QTLivePixelSource(40, 30, 30); //30 frames/second, make
		// it bigger if you are getting lag
		video = new QTMoviePixelSource("test80.mov", false, true, true);
		//((QTMoviePixelSource) video).play();
		before = (int[]) video.getPixelArray().clone();  


	}

	float z = -10f;
	
	static float zoom = 1f;

	private boolean toomuch;

	/**
	 * set the camera position, field of view, depth.
	 */
	public static void setPerspective() {
		// select projection matrix (controls view on screen)
		GL11.glMatrixMode(GL11.GL_PROJECTION);
		GL11.glLoadIdentity();
		/* fovy,aspect,zNear,zFar */
		GLU.gluPerspective(30f * zoom, aspectRatio, 1f, 30f);
		GLU.gluLookAt(0f, 0f, 20f, 0f, 0f, 0f, 0f, 1f, 0f);

	}

	/**
	 * Render one frame. Called by GLApp.run().
	 */
	public void render() {
		// select model view for subsequent transforms
		GL11.glMatrixMode(GL11.GL_MODELVIEW);
		GL11.glLoadIdentity();

		// clear depth buffer and color
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
		GL11.glTranslatef(0.0f,0.0f,z);
		//System.out.println(rot);
		//GL11.glRotatef(rot,0.0f,1.0f,0.0f);
		//rot += 0.1f;
		video.grabFrame();

		int w = video.getVideoWidth();
		int h = video.getVideoHeight();
		int p = 0;

		int xstep = w / W;
		int ystep = h / H;
        
		//System.out.println(w + " " + h);
		
		ParticleSystem flyers = new ParticleSystem();
		
		//int[] scratchPad = (int[]) ps.getPixelArray().clone();
		for (int y = 0; y < h; y += ystep) {
			for (int x = 0; x < w; x += xstep) {
				int[] c1 = video.getPixel(x, h - y - 1);
				int[] c2 = video.getPixel(before,x,h - y - 1);
				int dist = (c1[1] - c2[1]) * (c1[1] - c2[1]) +
							(c1[2] - c2[2]) * (c1[2] - c2[2]) +
							(c1[3] - c2[3]) * (c1[3] - c2[3]);
				//System.out.println(p);
				psystems[p].setColor(c1);
				if (dist > 16000) {
					psystems[p].explode();
					ArrayList stuff = psystems[p].getParticles();
					for (int i = stuff.size()-1; i >= 0; i--) {
						Particle part = (Particle) stuff.get(i);
						stuff.remove(i);
						//if (flyers.size() < 100) {
						flyers.addParticle(part);
						//}
						/*if (flyers.size() > 10) {
							flyingSystems.add(flyers);
							flyers = new ParticleSystem();
							System.out.println(flyingSystems.size());
						}*/
					}
				}
				p++;
			}
		}
		

		
		if (!toomuch) {
		  flyingSystems.add(flyers);
		}
		//System.out.println(flyingSystems.size());
		
		before = (int[]) video.getPixelArray().clone();  

		int x = mouseX / (displayWidth / W);
		int y = mouseY / (displayHeight / H);

		
		for (int i = 0; i < psystems.length; i++) {
			psystems[i].run();
			if (psystems[i].dead()) {
				for (int n = 0; n < spotmax; n++) {
				  psystems[i].addParticle();
				}
			}
			/*if (psystems[i].size() < 3) {
				  psystems[i].addParticle();
			}*/
		}
		
		int totalp = 0;
		for (int i = flyingSystems.size()-1; i >=0; i--) {
			ParticleSystem ps = (ParticleSystem) flyingSystems.get(i);
			ps.run();
			totalp += ps.size();
			if (ps.dead()) {
				flyingSystems.remove(i);
			}
		}
		
		if (totalp > 12000) { toomuch = true; } else {toomuch = false;}
		
		if (akey) {
			if (up) coh_weight += 0.01f;
			if (down) coh_weight -= 0.01f;
			if (left) ali_weight += 0.01f;
			if (right) ali_weight -= 0.01f;
			coh_weight = constrain(coh_weight,0f,2.0f);
			ali_weight = constrain(ali_weight,0f,1.0f);			
			System.out.println("ali_weight: " + ali_weight + "  coh_weight: " + coh_weight);
		}
		


		//if (Math.random() < 0.01) {
		//psystems.add(new ParticleSystem(50,new
		// Vector3D(worldPos[0],worldPos[1],0)));
		//}
	}

	/**
	 * Convert the mouse position into world coordinates.
	 */
	public void mouseMove(int x, int y) {
		worldPos = getWorldCoordsAtScreen(x, y);
		mouseX = x;
		mouseY = y;
		//System.out.println("WorldPos=" + worldPos[0] + "," + worldPos[1] +
		// "," + worldPos[2]);
	}

	public void mouseDown(int x, int y) {
		//spherePos = getWorldCoordsAtScreen(x,y);
	}

	public void mouseUp(int x, int y) {
	}

	public void keyDown(int keycode) {
		System.out.println(keycode);
		akey = true;
		switch (keycode)
		{
		  case 200:
		  	up = true;
		  	break;
		  case 208:
		    down = true;
		    break;
		  case 203:
		  	left = true;
		  	break;
		  case 205:
		    right = true;
		    break;
		 }
		
	}

	public void keyUp(int keycode) {
		//System.out.println("UP");
		akey = false;
		switch (keycode)
		{
		  case 200:
		  	up = false;
		  	break;
		  case 208:
		    down = false;
		    break;
		  case 203:
		  	left = false;
		  	break;
		  case 205:
		    right = false;
		    break;		
		    }		
	}

	//------------------------------------------------------------------------
	// Run main loop of application. Handle mouse and keyboard input.
	//------------------------------------------------------------------------

	private Reve() {
	}

	public static void main(String args[]) {
		Reve reve = new Reve();
		reve.run(); // will call init(), render(), mouse functions
	}

}

