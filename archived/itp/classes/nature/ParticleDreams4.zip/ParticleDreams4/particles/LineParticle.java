/*
 * Created on Feb 24, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package particles;

import org.lwjgl.opengl.GL11;

/**
 * @author Administrator
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class LineParticle extends Particle {
	private int trail = 2;
	private int current = 0;
	//private Vector3D[] locs = new Vector3D[trail];
	Vector3D loc1;
	Vector3D loc2;
	
	LineParticle(Vector3D l) {
		super(l);
		trail = 5;
		current = 0;
		//locs = new Vector3D[trail];
		//for (int i = 0; i < locs.length;i++) {
		//  locs[i] = l.copy();	
		//}
		loc1 = l.copy();
		loc2 = l.copy();
	}

	void update() {
		super.update();
		//locs[current] = loc.copy();
		//current = (current + 1) % trail;
		current = (current + 1) % 2;
		if (current == 0)  loc1 = loc.copy();
		if (current == 1)  loc2 = loc.copy();
	}
	
	void render() {
		if (r+g+b > 0.2) {
			if (loc.z < 50) {
				float tsize = 0.1f;
				GL11.glDisable(GL11.GL_TEXTURE_2D);
				GL11.glEnable(GL11.GL_LINE_SMOOTH);
				GL11.glPushMatrix();
				GL11.glBegin(GL11.GL_LINE);
				//for (int i = 0; i < locs.length-1; i++) {
					GL11.glColor4f(r, g, b, timer);
					GL11.glVertex3f(loc1.x,loc1.y,loc1.z);
					GL11.glVertex3f(loc2.x,loc2.y,loc2.z);
				//}
				GL11.glEnd();

				/*GL11.glBegin(GL11.GL_LINES);
				for (int i = 0; i < locs.length-1; i++) {
					GL11.glColor4f(r, g, b, timer);
					GL11.glVertex3f(locs[i].x,locs[i].y,locs[i].z);
					GL11.glVertex3f(locs[i+1].x,locs[i+1].y,locs[i+1].z);
				}
				GL11.glEnd();*/
				GL11.glPopMatrix();
				GL11.glEnable(GL11.GL_TEXTURE_2D);
			}
		}
	}
	
	
}
