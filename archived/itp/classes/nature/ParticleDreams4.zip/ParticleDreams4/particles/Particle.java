/* A class to describe a one singular particle */

package particles;

//import org.lwjgl.*;
//import glStuff.Reve;

import java.util.ArrayList;
import org.lwjgl.opengl.*;

//import org.lwjgl.input.*;
//import org.lwjgl.opengl.glu.*;

public class Particle {
	protected Vector3D loc;
	private Vector3D vel;
	Vector3D acc;
	float r, g, b;
	float timer;
	float fade;
	boolean flying;
	float max_vel;
	float max_force;
	float[] distances;

	Particle(Vector3D l) {
		acc = new Vector3D(0, 0, 0);//0.001f);
		vel = new Vector3D(0, 0, 0);
		loc = l.copy();
		r = 10.0f;
		timer = 1.0f;
		fade = (float) Math.random() * 0.02f + 0.003f;
		r = 0.0f;//(float) Math.random();
		g = 0.0f;//(float) Math.random();
		b = 0.0f;//(float) Math.random();
		flying = false;

		max_vel = 0.5f;//(float) Math.random()*0.2f;
		max_force =(float) Math.random()*0.04f;
        //System.out.println("a part");
		//distances = new float[200];

	}

	void setColor(int[] rgb) {
		float p1 = 0.5f;
		float p2 = 1.0f - p1;
		if (!flying) {
			r = p1*r + p2*rgb[1] / 255.0f;
			g = p1*g + p2*rgb[2] / 255.0f;
			b = p1*b + p2*rgb[3] / 255.0f;
		}
	}

	/*void run() {
		update();
		//loc.setXYZ(0,0,20f);
		if (flying)
		render();
	}*/
	
	void run(Vector3D ali, Vector3D coh) {
		update();
		if (flying) {
			steer(ali,coh);
		}
		//if (flying)
		render();
	}

	void steer(Vector3D ali, Vector3D co) {
		float coh_weight = glStuff.Reve.coh_weight;//1.00f;
		//float sep_weight = 0.0f;
		float ali_weight = glStuff.Reve.ali_weight;//0.9f;
		acc.setXYZ(0, 0, 0);
		Vector3D coh = steering(co);
		//Vector3D sep = separate(p);
		//Vector3D ali = align(p);
		coh.mult(coh_weight);
	    ali.mult(ali_weight);
		//sep.mult(sep_weight);
		//ali.mult(max_force);
		//ali.limit(max_vel);
		acc.add(coh);
		//acc.add(sep);
		acc.add(ali);
		//acc.add(new Vector3D(0,0,0.1f));
		//vel = ali.copy();
	}

	//function to update location
	void update() {
		vel.add(acc);
		vel.limit(max_vel);
		loc.add(vel);
		//locs[current] = loc.copy();
		//current = (current + 1) % trail;
		
		timer -= fade;
	}

	//function to display
	void render() {
		if (r+g+b > 0.2) {
			if (loc.z < 50) {
				float tsize = 0.1f;
				//if (flying) {
				GL11.glPushMatrix();
				GL11.glTranslatef(loc.x, loc.y, loc.z);
				GL11.glColor4f(r, g, b, timer);
				GL11.glBegin(GL11.GL_QUADS); // Build Quad From A Triangle Strip
				GL11.glTexCoord2f(0.0f, 0.0f);
				GL11.glVertex3f(-tsize, -tsize, 0); // Bottom Left
				GL11.glTexCoord2f(1.0f, 0.0f);
				GL11.glVertex3f(+tsize, -tsize, 0); // Bottom Right
				GL11.glTexCoord2f(1.0f, 1.0f);
				GL11.glVertex3f(+tsize, +tsize, 0); // Top Right
				GL11.glTexCoord2f(0.0f, 1.0f);
				GL11.glVertex3f(-tsize, +tsize, 0); // Top Left
				GL11.glEnd();// Done Building Triangle Strip
				GL11.glPopMatrix();
			}
		}
	}

	void launch() {
		if (!flying) {
		  vel = new Vector3D((float)Math.random()*0.04f-0.02f,(float)Math.random()*0.04f-0.02f,(float)Math.random()*0.25f);
		  timer = 1.0f;
		  flying = true;
		}
	}

	public boolean flying() {
		return flying;
	}

	boolean dead() {
		if (timer <= 0.0) {
			return true;
		} else {
			return false;
		}
	}

	void calc_distances(ArrayList boids) {
		//distances = new float[boids.size()];
		for (int i = 0; i < boids.size(); i++) {
			Particle boid = (Particle) boids.get(i);
			distances[i] = Vector3D.distance(loc, boid.getLoc());
		}
	}



	Vector3D separate(ArrayList b) {
		Vector3D sum = new Vector3D(0, 0, 0);

		int count = 0;
		for (int i = 0; i < b.size(); i++) {
			Particle boid = (Particle) b.get(i);
			//float d = Vector3D.distance(boid.getLoc(),loc);
			float d = distances[i];
			if ((d > 0)) {// && (d < sep_radius)) {
				Vector3D diff = Vector3D.sub(loc, boid.getLoc());
				diff.normalize();
				diff.div(d);
				sum.add(diff);
				count++;
			}
		}
		if (count > 0) {
			sum.div((float) count);
			return sum;
		} else {
			return new Vector3D(0, 0, 0);
		}
	}



	Vector3D steering(Vector3D target) {
		Vector3D steering = Vector3D.sub(target, loc);
		float mag = steering.magnitude();
		if (mag > 0) {
			steering.div(mag);
			steering.mult(max_vel);
			steering.sub(vel);
			steering.limit(max_force);
			return steering;
		} else {
			return new Vector3D(0, 0, 0);
		}
	}

	/**
	 * @param loc
	 *            The loc to set.
	 */
	void setLoc(Vector3D loc) {
		this.loc = loc;
	}

	/**
	 * @return Returns the loc.
	 */
	Vector3D getLoc() {
		return loc;
	}

	/**
	 * @param vel
	 *            The vel to set.
	 */
	void setVel(Vector3D vel) {
		this.vel = vel;
	}

	/**
	 * @return Returns the vel.
	 */
	Vector3D getVel() {
		return vel;
	}

}

