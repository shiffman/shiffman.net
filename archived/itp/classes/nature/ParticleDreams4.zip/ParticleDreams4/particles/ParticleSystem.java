/*A class to describe a group of Particles*/

package particles;

import java.util.*;

public class ParticleSystem {

  ArrayList particles;    //an arraylist for all the particles
  Vector3D origin;        //an origin point for where particles are birthed
  //boolean flying;
  int id;
  float max_force;

  public ParticleSystem(int num, Vector3D v) {
    particles = new ArrayList();              //initialize the arraylist
    origin = v.copy();                        //store the origin point
    for (int i = 0; i < num; i++) {
      particles.add(new Particle(origin));    //add "num" amount of particles to the arraylist
    }
    //flying = false;
    max_force = 0.1f;
  }
  
  //make an empty one
  public ParticleSystem() {
  	particles = new ArrayList();
  	origin = new Vector3D(0,0,0);
  }
   
  public void explode() {
    for (int i = particles.size()-1; i >= 0; i--) {
        Particle p = (Particle) particles.get(i);
        if (!p.flying()) {
          p.launch();
        }
    }
    //flying = true;
  }
  
  public void setColor(int[] rgb) {
    for (int i = 0; i < particles.size(); i++) {
    	Particle p = (Particle) particles.get(i);
    	p.setColor(rgb);
    }
  }
  
  /*public boolean flying() {
  	return flying;
  }*/
  
  /*public void run(ArrayList stuff) {
    //cycle through the ArrayList backwards b/c we are deleting
    for (int i = particles.size()-1; i >= 0; i--) {
      Particle p = (Particle) particles.get(i);
      p.run(stuff);
      //if (p.dead()) {
        //p.restart();
        //particles.remove(i);
      //}
    }
    //System.out.println(particles.size());
  }*/
  
  public void run() {
    //cycle through the ArrayList backwards b/c we are deleting
  	Vector3D ali = align();
  	Vector3D coh = cohesion();
    for (int i = particles.size()-1; i >= 0; i--) {
      Particle p = (Particle) particles.get(i);
      p.run(ali, coh);
      if (p.dead()) {
        //p.restart();
        particles.remove(i);
      }
    }
    //System.out.println(particles.size());
  }

  public void addParticle() {
    particles.add(new LineParticle(origin));
    //particles.add(new Particle(origin));
  }

  public void addParticle(Particle p) {
    particles.add(p);
  }
  
  public int size() {
   return particles.size();	
  }
  //a function to test if the particle system still has particles
  public boolean dead() {
    if (particles.isEmpty()) {
      return true;
    } else {
      return false;
    }
  }
  
  public ArrayList getParticles() {
    return particles;	
  }
  
	Vector3D align() {
		//System.out.println(this);
		Vector3D sum = new Vector3D(0, 0, 0);
		int count = 0;
		for (int i = 0; i < particles.size(); i++) {
			Particle boid = (Particle) particles.get(i);
			sum.add(boid.getVel());
			count++;
		}
		if (count > 0) {
			sum.div((float) count);
			//sum.limit(max_force);
			return sum;
		} else {
			return new Vector3D(0, 0, 0);
		}
	}  

	Vector3D cohesion() {
		Vector3D sum = new Vector3D(0, 0, 0);
		int count = 0;
		for (int i = 0; i < particles.size(); i++) {
			Particle boid = (Particle) particles.get(i);
			sum.add(boid.getLoc());
			count++;
		}

		if (count > 0) {
			sum.div((float) count);
			return sum;
		} else {
			return new Vector3D(0, 0, 0);
		}
	}	
	
	
}

