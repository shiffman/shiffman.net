
package nehe;

import particles.*;

import org.lwjgl.opengl.GL11;
//import org.lwjgl.opengl.glu.GLU;


public class ParticleTest extends Lesson04 {
	
	ParticleSystem ps;
	
	public static void main(String args[]) {
		boolean fullscreen = false;
		ParticleTest pt = new ParticleTest();
		pt.run(fullscreen);
	}
	
	protected void initGL() {
		super.initGL();
		ps = new ParticleSystem(1,new Vector3D(0.0f,5.0f,-20.0f));
		GL11.glEnable(GL11.GL_BLEND); // Enable Blending
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE); // Type Of Blending To
	}
	
	protected boolean render() {
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);          // Clear The Screen And The Depth Buffer
		GL11.glLoadIdentity();                          // Reset The Current Modelview Matrix
		ps.run();
		ps.addParticle();	
		return true;
	}
}
