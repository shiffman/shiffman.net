/*
 *      This Code Was Created By Jeff Molofee 2000
 *      A HUGE Thanks To Fredric Echols For Cleaning Up
 *      And Optimizing The Base Code, Making It More Flexible!
 *      If You've Found This Code Useful, Please Let Me Know.
 *      Visit My Site At nehe.gamedev.net
 */


package nehe;

import particles.*;

import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;

import org.lwjgl.opengl.glu.GLU;
import org.lwjgl.input.Keyboard;

/**
 * @author Mark Bernard
 * date:    16-Nov-2003
 *
 * Port of NeHe's Lesson 4 to LWJGL
 * Title: Rotation
 * Uses version 0.94alpha of LWJGL http://www.lwjgl.org/
 *
 * Be sure that the LWJGL libraries are in your classpath
 *
 * Ported directly from the C++ version
 *
 * 2004-05-08: Updated to version 0.9alpha of LWJGL.
 *             Changed from all static to all instance objects.
 * 
 * 30-Jan-2005: Updated to use version 0.94alpha of LWJGL.
 *  Changed Window to use Display
 * 
 */
public class Lesson04 {
	private boolean done = false;
	private boolean fullscreen = false;
	private final String windowTitle = "NeHe's OpenGL Lesson 4 for LWJGL (Rotation)";
	private boolean f1 = false;
	
	private float rtri;                 // Angle For The Triangle ( NEW )
	private float rquad;                // Angle For The Quad     ( NEW )
	
	private DisplayMode mode;
	
	public static void main(String args[]) {
		boolean fullscreen = false;
		if(args.length>0) {
			if(args[0].equalsIgnoreCase("fullscreen")) {
				fullscreen = true;
			}
		}
		
		Lesson04 l4 = new Lesson04();
		l4.run(fullscreen);
	}
	public void run(boolean fullscreen) {
		this.fullscreen = fullscreen;
		try {
			init();
			while (!done) {
				mainloop();
				render();
				Display.update();
			}
			cleanup();
		}
		catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
	}
	private void mainloop() {
		Keyboard.poll();
		if(Keyboard.isKeyDown(Keyboard.KEY_ESCAPE)) {       // Exit if Escape is pressed
			done = true;
		}
		if(Display.isCloseRequested()) {                     // Exit if window is closed
			done = true;
		}
		if(Keyboard.isKeyDown(Keyboard.KEY_F1) && !f1) {    // Is F1 Being Pressed?
			f1 = true;                                      // Tell Program F1 Is Being Held
			switchMode();                                   // Toggle Fullscreen / Windowed Mode
		}
		if(!Keyboard.isKeyDown(Keyboard.KEY_F1)) {          // Is F1 Being Pressed?
			f1 = false;
		}
	}
	
	private void switchMode() {
		Display.destroy();
		fullscreen = !fullscreen;
		try {
			createWindow();
		}
		catch(Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
		initGL();
	}
	
	protected boolean render() {
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);          // Clear The Screen And The Depth Buffer
		
		GL11.glLoadIdentity();                          // Reset The Current Modelview Matrix
		
		GL11.glTranslatef(-1.5f,0.0f,-6.0f);                // Move Left 1.5 Units And Into The Screen 6.0
		GL11.glRotatef(rtri,0.0f,1.0f,0.0f);                // Rotate The Triangle On The Y axis ( NEW )
		GL11.glBegin(GL11.GL_TRIANGLES);                    // Drawing Using Triangles
		GL11.glColor3f(1.0f,0.0f,0.0f);             // Set The Color To Red
		GL11.glVertex3f( 0.0f, 1.0f, 0.0f);         // Move Up One Unit From Center (Top Point)
		GL11.glColor3f(0.0f,1.0f,0.0f);             // Set The Color To Green
		GL11.glVertex3f(-1.0f,-1.0f, 0.0f);         // Left And Down One Unit (Bottom Left)
		GL11.glColor3f(0.0f,0.0f,1.0f);             // Set The Color To Blue
		GL11.glVertex3f( 1.0f,-1.0f, 0.0f);         // Right And Down One Unit (Bottom Right)
		GL11.glEnd();                                       // Finished Drawing The Triangle
		
		GL11.glLoadIdentity();                          // Reset The Current Modelview Matrix
		GL11.glTranslatef(1.5f,0.0f,-6.0f);             // Move Right 1.5 Units And Into The Screen 6.0
		GL11.glRotatef(rquad,1.0f,0.0f,0.0f);               // Rotate The Quad On The X axis ( NEW )
		GL11.glColor3f(0.5f,0.5f,1.0f);                 // Set The Color To Blue One Time Only
		GL11.glBegin(GL11.GL_QUADS);                        // Draw A Quad
		GL11.glVertex3f(-1.0f, 1.0f, 0.0f);         // Top Left
		GL11.glVertex3f( 1.0f, 1.0f, 0.0f);         // Top Right
		GL11.glVertex3f( 1.0f,-1.0f, 0.0f);         // Bottom Right
		GL11.glVertex3f(-1.0f,-1.0f, 0.0f);         // Bottom Left
		GL11.glEnd();                                       // Done Drawing The Quad
		
		rtri += 0.2f;                                       // Increase The Rotation Variable For The Triangle ( NEW )
		rquad -= 0.15f;                                 // Decrease The Rotation Variable For The Quad     ( NEW )
		
		return true;
	}
	
	private void createWindow() throws Exception {
		
		//start of in windowed mode
		mode = findDisplayMode(800, 600, 16);
		Display.create();
		//sync frame (only works on windows) and linux apparently
		Display.setVSyncEnabled(true);
		
	}
	private DisplayMode findDisplayMode(int width, int height, int bpp) {
		DisplayMode[] modes = Display.getAvailableDisplayModes();
		
		for (int i = 0; i < modes.length; i++) {
			if (modes[i].getWidth() == width && modes[i].getHeight() == height && modes[i].getBitsPerPixel() >= bpp && modes[i].getFrequency() <= 85) {
				try {
					Display.setDisplayMode(modes[i]);
				} catch (LWJGLException e) {
					e.printStackTrace();
				}
				return modes[i];
			}
		}
		return null;
	}
	
	
	private void init() throws Exception {
		createWindow();
		
		Keyboard.create();
		
		initGL();
	}
	protected void initGL() {
		GL11.glEnable(GL11.GL_TEXTURE_2D); // Enable Texture Mapping
		GL11.glShadeModel(GL11.GL_SMOOTH); // Enable Smooth Shading
		GL11.glClearColor(0.0f, 0.0f, 0.0f, 0.0f); // Black Background
		GL11.glClearDepth(1.0); // Depth Buffer Setup
		GL11.glEnable(GL11.GL_DEPTH_TEST); // Enables Depth Testing
		GL11.glDepthFunc(GL11.GL_LEQUAL); // The Type Of Depth Testing To Do
		
		GL11.glMatrixMode(GL11.GL_PROJECTION); // Select The Projection Matrix
		GL11.glLoadIdentity(); // Reset The Projection Matrix
		
		// Calculate The Aspect Ratio Of The Window
		GLU.gluPerspective(
				45.0f,
				(float)800 / (float) 600, // these being screen width and height
				0.1f,
				100.0f);
		GL11.glMatrixMode(GL11.GL_MODELVIEW); // Select The Modelview Matrix
		
		// Really Nice Perspective Calculations
		GL11.glHint(GL11.GL_PERSPECTIVE_CORRECTION_HINT, GL11.GL_NICEST);
	}
	private void cleanup() {
		Keyboard.destroy();
		Display.destroy();
	}
	
}