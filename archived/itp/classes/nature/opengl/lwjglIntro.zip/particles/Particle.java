/*A class to describe a one singular particle*/
package particles;

//import org.lwjgl.LWJGLException;
//import org.lwjgl.opengl.Display;
//import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;

//import org.lwjgl.opengl.glu.GLU;
//import org.lwjgl.input.Keyboard;

class Particle {
  Vector3D loc;
  Vector3D vel;
  Vector3D acc;
  float r;
  float timer;

  //The Constructor (called when the object is first created)
  Particle(Vector3D a, Vector3D v, Vector3D l, float r_) {
    acc = a.copy();
    vel = v.copy();
    loc = l.copy();
    r = r_;
    timer = 100.0f;
  }
  
  //look, we can have more than one constructor!
  Particle(Vector3D l) {
    acc = new Vector3D(0,-0.0005f,0);
    //ooooh, bad random, random bad
    vel = new Vector3D((float) Math.random()*0.06f - 0.03f,(float) Math.random()* 0.03f,(float) Math.random()* 0.06f);
    loc = l.copy();
    r = 0.2f;
    timer = 1.0f;
  }


  void run() {
    update();
    render();
  }

  //function to update location
  void update() {
    vel.add(acc);
    loc.add(vel);
    timer -= 0.002;
  }

  //function to display
  void render() {
  	
  	GL11.glPushMatrix();
	GL11.glTranslatef(loc.x(),loc.y(),loc.z());             // Move Right 1.5 Units And Into The Screen 6.0
	GL11.glColor4f(1.0f,1.0f,1.0f,timer);                 // Set The Color To Blue One Time Only
	GL11.glBegin(GL11.GL_QUADS);                        // Draw A Quad
	  GL11.glVertex3f(-r, r, 0.0f);         // Top Left
	  GL11.glVertex3f( r, r, 0.0f);         // Top Right
	  GL11.glVertex3f( r,-r, 0.0f);         // Bottom Right
	  GL11.glVertex3f(-r,-r, 0.0f);         // Bottom Left
	  GL11.glEnd();        
  	GL11.glPopMatrix();
  	
    //ellipseMode(CENTER);
    //noStroke();
    //fill(0,100,255,timer);
    //ellipse(loc.x(),loc.y(),r,r);
  }
  
  //is the particle still useful?
  boolean dead() {
    if (timer <= 0.0) {
      return true;
    } else {
      return false;
    }
  }
}


