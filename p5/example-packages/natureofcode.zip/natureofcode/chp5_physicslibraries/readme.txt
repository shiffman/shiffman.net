For the box2d examples you will need Box2D For Processing!

https://github.com/shiffman/Box2D-for-Processing/
