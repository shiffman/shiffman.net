/* Daniel Shiffman               */
/* Spring 2006                   */
/* http://www.shiffman.net       */
/* daniel.shiffman@nyu.edu       */

// Simple Carnivore Class        
// Based heavily on Mark Napier's example
// http://www.rhizome.org/carnivore/

public class Carnivore {
    
    // Default connection info
    String carnivoreIP = "127.0.0.1";
    int carnivorePort = 6667;
    CarnivoreListener carni;

    public Carnivore() {

    }

    public void start() {
        System.out.println("Carnivore listener started");
        startStream();
    }

    public void stop() {
        stopStream();
    }

    public void startStream()
    {
        carni = new CarnivoreListener(this);
        carni.setSocket(carnivoreIP, carnivorePort);
        carni.startListening();
    }

    public void stopStream()
    {
        if (carni != null) {
            carni.stopListening();
        }
    }

    /////////////////////////////////////////////
    // Handle carni input
    
    String currentLine = "";
    int currLinePos = 0;

    // This will be called if CarnivoreListener.processHexBytes = true
    public synchronized void showByte(byte b)
    {
        currentLine = "" + ((int)(b & 0xFF));
    }

    // This is called if processing line by line (default)
    public synchronized void showLine(String line)
    {
        currentLine = line;
    }

    public synchronized void processLine() {
        System.out.println(currentLine);
    }


}
