/* Daniel Shiffman               */
/* Spring 2006                   */
/* http://www.shiffman.net       */
/* daniel.shiffman@nyu.edu       */

// Simple Carnivore App        
// Based heavily on Mark Napier's example
// http://www.rhizome.org/carnivore/

////////////////////////////////////////////////////////////
// CarnivoreApp
//
// 
////////////////////////////////////////////////////////////

public class CarnivoreApp {
 
    public static void main(String[] args) {
        System.out.println("Carnivore app starting. . .");
        Carnivore c = new Carnivore();
        c.start();
                
    }
}


