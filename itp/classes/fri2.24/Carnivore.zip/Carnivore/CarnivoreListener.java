import java.io.*;
import java.net.*;
import java.util.StringTokenizer;

// Mark Napier's Example
// Updated to include a BufferedReader

/////////////////////////////////////////////////////////////////////////
//  CarnivoreListener
//
//  A Stream Listener that reads packets from Carnivore server, file, or URL.
//
// Ctor:    new CarnivoreListener(CarnivorePanel)
//
//  This class will call showLine() on the CarnivorePanel every time a line
//  comes through the input stream.  Can also proces packets byte-by-byte (see
//  processLineHex()).
//
//  How to use:
//    CarnivoreListener CL = new CarnivoreListener(aCarnivorePanel);
//    if (connectToCarnivoreSocket) {
//      CL.setSocket(carnivoreIP, carnivorePort);
//    }
//    else if (connectToFile) {
//      CL.setFile("carnivore_data.txt");
//    }
//    else if (connectToURL) {
//      CL.setURL("http://somedomain.com/cgi-bin/carnivore_client_zero.pl");
//    }
//    CL.startListening();
//
//  Note:
//    1) The function processLine() sends lines or bytes to parent application.
//    2) Customize processLine() to change behavior.
//    3) The parent application (or applet or panel) has to have a function
//         called "showLine(String line)" and/or "showByte(byte b)" that will do
//         something with the lines and/or bytes that the
//         listener reads from Carnivore (see processLine()).
//
// 
// Copyright (C) May 2003 by Mark Napier
// 
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation; either version 2 of the License, or (at your
// option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.
// 
////////////////////////////////////////////////////////////

class CarnivoreListener implements Runnable {
    // 3 ways to get data: "socket|url|file"
    String how = "socket";
    
    // For connecting to socket
    String Host = "127.0.0.1";
    int Port = 6667;
    
    // Stream stuff
    Socket s;
    URL dataURL = null;
    URLConnection uc = null;
    DataInputStream in;
    BufferedReader reader;
    PrintStream out;
    boolean connected = false;
    boolean stopthread = false;
    
    // These classes handle display of data
    Carnivore carniPanel;
    
    int bit = 0;
    // By default process hex values in packets
    // Set to true to process plain bytes
    boolean processHexBytes = false;
    
    // Runs the listener
    Thread runner;
    
    ////////////////////////////////////////////////////
    // Start the Carni listener with the output panel as param.
    // Set default connection method to Carnivore Server.
    
    public CarnivoreListener(Carnivore carniPanel) {
        this.carniPanel = carniPanel;
        setSocket();
    }
    
    /////////////////////////////////////////////////////
    // Process text lines from Carni Server
    // Customize this to change what happens with each line.
    // If you set processHexBytes = true, then the processLineHex() function
    // will break packet data into bytes, and will call processByte()
    // for each byte.
    
    public void processLine(String line)
    {
        if (processHexBytes) {
            processLineHex(line);
        }
        else {
            processLineRaw(line);
        }
    }
    
    // Send a line to the panel
    public void processLineRaw(String line)
    {
        carniPanel.showLine(line);
    }
    
    // Send a byte to the panel
    public void processByte(byte b)
    {
        carniPanel.showByte(b);
    }
    
    // Break packet into bytes and call processByte() for each
    public boolean processLineHex(String packet)
    {
        // Packet looks like:   "some header data, blah == 010f 2213 0020 bd01 00ae ..."
        // split line on "==",  right side of line has hex values
        int pos1 = packet.indexOf("==");
        if (pos1 < 0) {
            System.out.println("processLine: Never found '==' line=" + packet);
        }
        else {
            // parse list of hexvals.  each hexval is two bytes together (4 hex digits)
            String hexvals = packet.substring(pos1+2);
            StringTokenizer st = new StringTokenizer(hexvals," ");
            Integer i = null;
            String hexval="", hexval1="", hexval2;
            short s = 0;
            byte b = 0;
            //System.out.println("ProcessLine: " + hexvals);
            while (st.hasMoreTokens()) {
                hexval = st.nextToken();
                if (hexval.length() >= 4 && !hexval.equals("(DF)")) {  // check valid token
                    hexval1 = "0x" + hexval.substring(0, 2);        // left byte
                    hexval2 = "0x" + hexval.substring(2, 4);        // rite byte
                    // byte 1
                    try {
                        i = Integer.decode(hexval1);
                        b = i.byteValue();
                        processByte(b);
                    }
                    catch (Exception e) {
                        message("Exception: HEX=" + hexval1 + " " + e);
                    }
                    // byte 2
                    try {
                        i = Integer.decode(hexval2);
                        b = i.byteValue();
                        processByte(b);
                    }
                    catch (Exception e) {
                        message("Exception: HEX=" + hexval2 + " " + e);
                    }
                }   // end of if token length >= 4
            }
        }
        return true;
    }
    
    
    public void setSocket() {
        setSocket(Host,Port);
    }
    
    public void setSocket(String h, int p) {
        if (h != null && h != "") {
            Host = h;
        }
        if (p > 0) {
            Port = p;
        }
        message("CarnivoreListener: Use Socket " + Host + " " + Port);
        how = "socket";
    }
    
    
    /////////////////////////////////////////////////////
    // Start/stop the listening loop
    
    public void startListening() {
        // Start the repaint thread
        runner = new Thread(this);
        runner.start();
        stopthread = false;
    }
    
    
    public void stopListening() {
        runner = null;
        stopthread = true;
        disconnectFromServer();
    }
    
    
    /////////////////////////////////////////////////////
    // connect to the data source
    // may be a URL, file, or socket
    
    public boolean connectToServer() {
        connected = false;
        message("Connecting to host " + Host + ":" + Port + "...");
        try {
            // connect to server socket
            s = new Socket(Host,Port);
            // to read from server
            in = new DataInputStream(s.getInputStream());
            reader = new BufferedReader(new InputStreamReader(in));
            // to send to server
            out = new PrintStream(s.getOutputStream());
            message("Connected to " + Host + ":" + Port);
            connected = true;
        }
        catch (Exception e) {
            message("connect(): " + e);
            connected = false;
        }
        
        // Got the connection.  If Socket, do hand-shake
        if (connected) {
            int rand = (int)(Math.random()*999999);
            message("send user");
            sendToServer("USER bw" +rand+ "\n");
            message("send nick");
            sendToServer("NICK bw" +rand+ "\n");
            String ping = readFromServer();
            String pong = "PONG" + ping.substring(4)+"\n";
            message("read  " + ping);
            message("write " + pong);
            sendToServer(pong);
            message("write JOIN");
            sendToServer("JOIN #hexivore\n");
        }
        return connected;
    }
    
    
    public String readFromServer() {
        String line = "nada";
        try {
            // get a line from the server
            line =  reader.readLine();
        }
        catch (Exception e) {
            message("Error when reading  " + Host + " " + Port + ": " + e);
        }
        return line;
    }
    
    
    public void sendToServer(String s) {
        if (out != null) {
            try {
                out.print(s);
                Thread.sleep(500);
            }
            catch (Exception e) {
                message("Error when sending: " + e);
            }
        }
    }
    
    
    public void disconnectFromServer() {
        message("disconnect");
        try {
            if (out != null) {
                out.println("QUIT");
                out.close();
            }
            if (in != null) {
                in.close();
            }
        }
        catch (IOException e) {
            message("Error when closing inputStream: " + e);
        }
        connected = false;
    }
    
    
    /////////////////////////////////////////////////////
    // Thread runs in two states
    // 1) loop until connected to server
    // 2) read lines until thread stops or socket fails
    //    if socket fails, return to state 1.
    //
    public void run() {
        String line;
        connected = false;
        message("run()");
        while (stopthread==false) {
            // Get connection
            while (connected==false && stopthread==false) {
                if (connectToServer() == false) {
                    try{
                        Thread.sleep(60000);  // retry in 60 secs
                    } catch (InterruptedException e) {
                        message("Interrupted: " + e);
                    }
                }
            }
            // Read lines from Carni Server
            try {
                byte bb=0;
                while (connected==true && stopthread==false) {
                    line = reader.readLine();
                    if (line == null) {
                        break;
                    }
                    processLine(line);
                    // Yield a little time for repaint operations to work
                    Thread.sleep(10);
                }
            }
            catch (Exception e) {
                message("Error when listening to " + Host + " " + Port + ": " + e);
            }
            finally {
                message("Connection closed by server.");
                disconnectFromServer();
                // will loop back to connectToServer() to retry connection every 10 secs
            }
        }
    }
    
    
    public void message(String msg) {
        System.out.println("CarnivoreListener: " + msg);
    }
    
    
}

