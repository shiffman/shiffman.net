import java.util.ArrayList;

/* Daniel Shiffman               */
/* Binary Tree Class             */
/* Programming from A to Z       */
/* ITP, Spring 2006              */

// Simple Class to describe a word and count

public class Word
{
  private String word;
  private int count;
  private ArrayList positions;

  public Word(String s) {
     word = s;
     count = 1;
     positions = new ArrayList();
  }
  
  public void addPosition(int p) {
	  positions.add(new Integer(p));
  }
  
  public void count() {
    count++;
  }
  
  public ArrayList getPositions() {
	  return positions;
  }
  
  public int getCount() {
    return count;
  }
  
  public String getWord() {
    return word;
  }
}



