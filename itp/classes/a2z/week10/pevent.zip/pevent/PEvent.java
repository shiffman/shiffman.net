package pevent;

import processing.core.*;
import java.lang.reflect.*;


public class PEvent implements Runnable {

  PApplet parent;
  Method eventMethod;
  Thread runner;
  boolean available = false;
  int data;

  public PEvent(PApplet parent) {
    this.parent = parent;
    this.data = 0;
    runner = new Thread(this);
    runner.start();
    parent.registerDispose(this);
    try {
      eventMethod = parent.getClass().getMethod("myEvent", new Class[] { 
        PEvent.class             }
      );
    } 
    catch (Exception e) {
      System.out.println("Hmmm, event method no go?");
    }
  }
  
  public boolean available() {
    return available;
  }


  public int read() {
    available = false;
    return data;
  }


  public void run() {
      while (Thread.currentThread() == runner) {
          try {
              data++;
              available = true;
              if (eventMethod != null) {
                  try {
                      eventMethod.invoke(parent, new Object[] { 
                              this                     }
                      );
                  } 
                  catch (Exception e) {
                      System.err.println("Oopsies.");
                      e.printStackTrace();
                      eventMethod = null;
                  }
              }
              Thread.sleep(1000);
          } catch (Exception e) {
              
          }
      }
  }

  /**
   * Called by applets to stop.
   */
  public void stop() {
    runner = null; // unwind the thread
  }

  /**
   * Called by PApplet to shut down
   */
  public void dispose() {
    stop();
    System.out.println("calling dispose");
  }

}
