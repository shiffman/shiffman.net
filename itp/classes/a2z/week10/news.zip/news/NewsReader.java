package news;

import processing.core.*;
import java.lang.reflect.*;
import java.util.ArrayList;

import org.w3c.dom.Element;
import org.w3c.dom.Node;


public class NewsReader implements Runnable {

  PApplet parent;
  Method eventMethod;
  Thread runner;
  boolean available = false;
  private ArrayList headlines;
  private int maxheadlines;
  private int wait;

  public NewsReader(PApplet parent, int m, int w) {
    this.parent = parent;
    maxheadlines = m;
    wait = w;
    runner = new Thread(this);
    runner.start();
    parent.registerDispose(this);
    try {
      eventMethod = parent.getClass().getMethod("newsEvent", new Class[] { 
        NewsReader.class             }
      );
    } 
    catch (Exception e) {
      System.out.println("Hmmm, event method no go?");
    }
  }
  
  public boolean available() {
    return available;
  }


  public ArrayList read() {
    available = false;
    return headlines;
  }


  public void run() {
      while (Thread.currentThread() == runner) {
          try {
              check();
              available = true;
              if (eventMethod != null) {
                  try {
                      eventMethod.invoke(parent, new Object[] { 
                              this                     }
                      );
                  } 
                  catch (Exception e) {
                      System.err.println("Oopsies.");
                      e.printStackTrace();
                      eventMethod = null;
                  }
              }
              Thread.sleep(wait);
          } catch (Exception e) {
              
          }
      }
  }

  /**
   * Called by applets to stop.
   */
  public void stop() {
    runner = null; // unwind the thread
  }

  /**
   * Called by PApplet to shut down
   */
  public void dispose() {
    stop();
    System.out.println("calling dispose");
  }
  
  private synchronized void check() {
      headlines = new ArrayList();
      // Create a URL object and open an InputStream
      A2ZXmlReader xmlreader = null;
      try {
        xmlreader = new A2ZXmlReader("http://itp.nyu.edu/icm/proxy/proxy.php?url=http://news.google.com/?output=rss");
        // Call our recursive search function to locate the element we want

        ArrayList elements = new ArrayList();
        xmlreader.fillArrayList(xmlreader.getRoot(),"title",elements);
        for (int i = 0; i < elements.size(); i++) {
          Element e = (Element) elements.get(i);
          // As long as we find the element
          if (e != null) {
            Node n = e.getFirstChild();
            String headline = n.getNodeValue();
            headline = headline.replaceAll("&#39;","'");
            if ((!headline.matches("Google News")) && (headlines.size() < maxheadlines))  {
              headlines.add(headline);
            }
          }
        }
      } 
      catch (Exception e) {
        System.out.println("Something went wrong. " + e);
      }
    }
  
  

}
